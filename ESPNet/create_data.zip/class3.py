import json
import glob
from PIL import Image,ImageDraw
import os

lbl_dir_gen = "./label_1/"

pil_img = Image.open('2007_000032.png')
palette = pil_img.getpalette()

path=('./1/*.json')
fileList=glob.glob(path)

for i,f in enumerate(fileList):
    file = open(f, 'r')

    jsonData = json.load(file)
    h=jsonData['imageHeight']
    w=jsonData['imageWidth']
    points=jsonData['shapes'][0]['points']
    array=[]
    for j,p in enumerate(points):
        array.append(p[0])
        array.append(p[1])

    if(len(jsonData['shapes'])>1):
        points2=jsonData['shapes'][1]['points']
        array2=[]
        for j,p in enumerate(points2):
            array2.append(p[0])
            array2.append(p[1])

    basename=os.path.basename(f)
    root_ext_pair = os.path.splitext(basename)
    file.close()

    im = Image.new('P', (w, h))
    draw = ImageDraw.Draw(im)
    draw.polygon(array, fill=1, outline=255)#fill=21
    if(len(jsonData['shapes'])>1):
        draw.polygon(array2, fill=2, outline=255)#fill=21
    im.putpalette(palette)
    im.save(lbl_dir_gen + root_ext_pair[0] + ".png", quality = 100)
